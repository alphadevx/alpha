[Module]
antx-independents-pkg

[Ordered Module Dependencies]
java-essence-pkg
antx-independents-pkg

[Ordered Package Dependencies]
apis
helpers
parameters

[CVS Id]
----------------------------------------------------------------------
$Id: README-independents-pkg.txt 180 2007-03-15 12:56:38Z ssmc $
