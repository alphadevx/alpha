[Module]
antx-flowcontrol-pkg

[Ordered Module Dependencies]
java-apis-pkg
antx-strings-pkg
antx-core-pkg
antx-flowcontrol-pkg

[Ordered Package Dependencies]
flowcontrol
tests
testsmodule

[CVS Id]
----------------------------------------------------------------------
$Id: README-flowcontrol-pkg.txt 180 2007-03-15 12:56:38Z ssmc $
