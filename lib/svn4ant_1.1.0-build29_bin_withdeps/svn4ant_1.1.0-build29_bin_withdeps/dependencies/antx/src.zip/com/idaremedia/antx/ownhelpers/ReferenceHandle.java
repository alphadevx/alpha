/**
 * $Id: ReferenceHandle.java 180 2007-03-15 12:56:38Z ssmc $
 * Copyright 2005 iDare Media, Inc. All rights reserved.
 *
 * Originally written by iDare Media, Inc. for release into the public domain. This
 * library, source form and binary form, is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License (LGPL) as published
 * by the Free Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.<p>
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU LGPL for more details.<p>
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite
 * 330, Boston, MA  02111-1307  USA. The GNU LGPL can be found online at
 * http://www.fsf.org/copyleft/lesser.html<p>
 *
 * This product has been influenced by several projects within the open-source community.
 * The JWare developers wish to acknowledge the open-source community's support. For more
 * information regarding the open-source products used within JWare, please visit the
 * JWare website.
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://www.jware.info                            EMAIL- inquiries@jware.info
 *----------------------------------------------------------------------------------------*
 **/

package com.idaremedia.antx.ownhelpers;

import  org.apache.tools.ant.ProjectComponent;
import  org.apache.tools.ant.types.Reference;

/**
 * Utility script element that lets you declare a reference as a standalone nested
 * element.
 *
 * @since     JWare/AntX 0.5
 * @author    ssmc, &copy;2005 <a href="http://www.jware.info">iDare&nbsp;Media,&nbsp;Inc.</a>
 * @version   0.5
 * @.safety   single
 * @.group    api,helper
 **/

public final class ReferenceHandle extends ProjectComponent
{
    /**
     * Initializes a new reference handle.
     **/
    public ReferenceHandle()
    {
    }


    /**
     * Sets this handle's referred-to thing's reference.
     * @param ref the reference (non-null)
     **/
    public void setRefId(Reference ref)
    {
        m_refId = ref;
    }


    /**
     * Returns this handle's referred-to thingy's reference.
     * Will return <i>null</i> if never set.
     **/
    public Reference getRefId()
    {
        return m_refId;
    }


    /**
     * Tells this handle's user whether a missing reference
     * is OK.
     * @param halt <i>true</i> if missing refid is bad.
     **/
    public void setHaltIfMissing(boolean halt)
    {
        m_haltIfMissing = halt ? Boolean.TRUE : Boolean.FALSE;
    }


    /**
     * Returns this handle's bad refid missing instruction.
     * Will return <i>null</i> if never set explicitly.
     **/
    public Boolean getHaltIfMissingFlag()
    {
        return m_haltIfMissing;
    }


    private Reference m_refId;
    private Boolean m_haltIfMissing;
}

/* end-of-ReferenceHandle.java */