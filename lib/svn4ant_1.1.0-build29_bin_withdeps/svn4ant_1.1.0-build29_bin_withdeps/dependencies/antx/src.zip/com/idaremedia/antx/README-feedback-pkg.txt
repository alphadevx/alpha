[Module]
antx-feedback-pkg

[Ordered Module Dependencies]
java-apis-pkg
antx-strings-pkg
antx-core-pkg
antx-feedback-pkg

[Ordered Package Dependencies]
print
feedback
tests
testsmodule

[CVS Id]
----------------------------------------------------------------------
$Id: README-feedback-pkg.txt 180 2007-03-15 12:56:38Z ssmc $
