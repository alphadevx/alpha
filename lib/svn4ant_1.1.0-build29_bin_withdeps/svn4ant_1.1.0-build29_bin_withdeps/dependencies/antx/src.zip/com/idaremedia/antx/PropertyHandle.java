/**
 * $Id: PropertyHandle.java 180 2007-03-15 12:56:38Z ssmc $
 * Copyright 2002-2003 iDare Media, Inc. All rights reserved.
 *
 * Originally written by iDare Media, Inc. for release into the public domain. This
 * library, source form and binary form, is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your option) any later
 * version.<p>
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU LGPL (GNU Lesser General Public License) for more details.<p>
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite
 * 330, Boston, MA  02111-1307  USA. The LGPL can be found online at
 * http://www.fsf.org/copyleft/lesser.html<p>
 *
 * This product has been influenced by several projects within the open-source community.
 * The JWare developers wish to acknowledge the open-source community's support. For more
 * information regarding the open-source products used within JWare, please visit the
 * JWare website.
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://www.jware.info                           EMAIL- inquiries@jware.info
 *----------------------------------------------------------------------------------------*
 **/

package com.idaremedia.antx;

import  org.apache.tools.ant.BuildException;

/**
 * A modifiable thread-local property. Modifiable properties are always stored as
 * strings; non-strings are converted using the strict {@linkplain Stringifier} helper.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2003 <a href="http://www.jware.info">iDare&nbsp;Media,&nbsp;Inc.</a>
 * @version  0.5
 * @.safety  guarded
 * @.group   impl,helper
 * @see      ExportedProperties
 **/

public final class PropertyHandle extends InheritableThreadLocal
{
    /**
     * Creates a new null-valued property handle.
     **/
    public PropertyHandle()
    {
    }

    /**
     * Updates this handle's property value. Only permits <i>null</i>,
     * strings, and strictly stringifiable object.
     * @throws BuildException if value is of un-stringable class
     * @see Stringifier
     **/
    public void set(Object value)
    {
        Object checked = value;

        if (checked!=null && !(checked instanceof String)) {
            checked = Stringifier.get(false).stringFrom(value,null);
            if (checked==null) {
                throw new BuildException(AntX.uistrs().get("export.only.strings"));
            }
        }

        super.set(checked);
    }
}

/* end-of-PropertyHandle.java */
