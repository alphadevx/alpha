/**
 * $Id: InnerString.java 180 2007-03-15 12:56:38Z ssmc $
 * Copyright 2002-2004 iDare Media, Inc. All rights reserved.
 *
 * Originally written by iDare Media, Inc. for release into the public domain. This
 * library, source form and binary form, is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation; either version 2.1 of the License, or (at your option) any
 * later version.<p>
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU LGPL (GNU Lesser General Public License) for more details.<p>
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite
 * 330, Boston, MA  02111-1307  USA. The LGPL can be found online at
 * http://www.fsf.org/copyleft/lesser.html<p>
 *
 * This product has been influenced by several projects within the open-source community.
 * The JWare developers wish to acknowledge the open-source community's support. For more
 * information regarding the open-source products used within JWare, please visit the
 * JWare website.
 *----------------------------------------------------------------------------------------*
 * WEBSITE- http://www.jware.info                           EMAIL- inquiries@jware.info
 *----------------------------------------------------------------------------------------*
 **/

package com.idaremedia.antx.helpers;

import  org.apache.tools.ant.Project;

/**
 * Brain-dead luggage String bean (ha-ha) that allows nested &lt;defaultmsg&gt; elements
 * and other simple "string holder" elements. The string's contents should be specified
 * as either a single 'value' attribute or as nested text.
 *
 * @since    JWare/AntX 0.1
 * @author   ssmc, &copy;2002-2004 <a href="http://www.jware.info">iDare&nbsp;Media,&nbsp;Inc.</a>
 * @version  0.5
 * @.safety  single
 * @.group   impl,helper
 **/

public final class InnerString
{
    /**
     * Creates new empty string.
     **/
    public InnerString()
    {
    }


    /**
     * Creates new predefined string.
     **/
    public InnerString(String it)
    {
        addText(it);
    }


    /**
     * <em>Replaces</em> this string's current text.
     * @param s the new text (non-null)
     * @since JWare/AntX 0.2
     **/
    public void setValue(String s)
    {
        m_It = s;
    }


    /**
     * Adds more text to this string.
     **/
    public void addText(String it)
    {
        m_It += it;
    }


    /**
     * Synonymn for {@linkplain #setValue setValue} that is
     * semantically more appropriate for some uses of this class.
     * @param s the new text (non-null)
     * @since JWare/AntX 0.2
     **/
    public void setName(String s)
    {
        setValue(s);
    }


    /**
     * Returns this string's current text.
     **/
    public String getText()
    {
        return m_It;
    }


    /**
     * Same as {@linkplain #getText getText()}.
     **/
    public String toString()
    {
        return getText();
    }


    /**
     * Same as {@linkplain #getText getText()} but with
     * embedded properties replaced with project definitions.
     * @param P project from which properties resolved
     **/
    public String toString(final Project P)
    {
        String s = getText();
        return (P!=null) ? Tk.resolveString(P,s) : s;
    }


    private String m_It="";
}

/* end-of-InnerString.java */
