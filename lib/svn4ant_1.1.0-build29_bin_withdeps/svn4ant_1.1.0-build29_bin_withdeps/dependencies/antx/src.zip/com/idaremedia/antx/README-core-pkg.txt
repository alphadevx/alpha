[Module]
antx-core-pkg

[Ordered Module Dependencies]
antx-strings-pkg
java-essence-pkg
antx-independents-pkg
antx-core-pkg

[Ordered Package Dependencies]
antx
ut
go
ownhelpers
starters
print capture
condition 
condition.solo init mktemp construct
solo
tests
testsmodule

[CVS Id]
----------------------------------------------------------------------
$Id: README-core-pkg.txt 180 2007-03-15 12:56:38Z ssmc $
